package utils;

public class SessionLocationData {
	private String sessionLocationName;
	


	public SessionLocationData(String sessionLocationName) {
		this.sessionLocationName = sessionLocationName;
		
	}

	public String getSessionLocationName() {
		return sessionLocationName;
	}

	public void setSessionLocationName(String sessionLocationName) {
		this.sessionLocationName = sessionLocationName;
	}
	
	
	
}
